// main function
fun main() {
    var counter = 1

    do {
        println("Hello, World!")
        counter++
    } while (counter <= 7)
}