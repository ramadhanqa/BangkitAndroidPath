// main function
fun main() {
    val color : Color = Color.RED
    print(color)
}

enum class Color{
    RED, GREEN, BLUE
}